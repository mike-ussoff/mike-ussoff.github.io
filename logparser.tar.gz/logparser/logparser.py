#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import traceback
import string
import curses
from html.parser import HTMLParser
import urllib.request
import time
from datetime import datetime, timedelta
import base64

BASE_URL = "http://stu1/ossec/prog/UnitList.php"
username = "obi"
password = "12345678"
typeauth = "PAM"
#typeauth = "Kerberos"


class MyHTMLParser(HTMLParser):
    lsLogs = list()
    lsRecord = list()

    def handle_starttag(self, startTag, attrs):
        if startTag == "alert":
            attr = dict(attrs)
            self.lsRecord = list()
            self.lsRecord.append(attr["level"])
            self.lsRecord.append(attr["hostname"])
            self.lsRecord.append(attr["date"])
            self.lsRecord.append(attr["time"])
            if attr["ip"] == "":  self.lsRecord.append("<none>")
            else: self.lsRecord.append(attr["ip"])
            #self.lsRecord.append(attr["groups"])
            #self.lsRecord.append(attr["source"])
            self.lsRecord.append(attr["description"])
        if startTag == "log":
            attr = dict(attrs)
            stmp = attr["text"].split(':')
            self.lsRecord.append('[' + stmp[len(stmp) - 1].strip() + ']')
            self.append_record()

    def append_record(self):
        is_found = False
        for rec in self.lsLogs:
            if rec == self.lsRecord:
                is_found = True
        if not is_found:
            self.lsLogs.append(self.lsRecord)


parser = MyHTMLParser()


def get_data():
    if typeauth == "Kerberos":
        req = urllib.request.Request(BASE_URL)
        credentials = ('%s:%s' % (username, password))
        encoded_credentials = base64.b64encode(credentials.encode('ascii'))
        req.add_header('Authorization', 'Basic %s' % encoded_credentials.decode('ascii'))
        s = str(urllib.request.urlopen(req).read().decode('utf-8'))
    else:
        password_mgr = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        password_mgr.add_password(None, BASE_URL, username, password)
        handler = urllib.request.HTTPBasicAuthHandler(password_mgr)
        opener = urllib.request.build_opener(handler)
        urllib.request.install_opener(opener)
        s = str(urllib.request.urlopen(BASE_URL).read().decode('utf-8'))
    parser.lsLogs = list()
    parser.lsRecord = list()
    parser.feed(s)


def getdatetimefromstr(date_str, time_str):
    datestr = date_str.split('.')
    timestr = time_str.split(':')
    return datetime(int(datestr[2]), int(datestr[1]), int(datestr[0]),
                    int(timestr[0]), int(timestr[1]), int(timestr[2]))


def draw_logs(stdscr):
    k = 0
    ccount = 0

    stdscr.erase()
    stdscr.refresh()
    stdscr.nodelay(True)
    curses.start_color()

    curses.init_pair(1, curses.COLOR_WHITE, curses.COLOR_BLACK)
    curses.init_pair(2, curses.COLOR_MAGENTA, curses.COLOR_BLACK)
    curses.init_pair(3, curses.COLOR_RED, curses.COLOR_BLACK)
    curses.init_pair(4, curses.COLOR_CYAN, curses.COLOR_BLACK)
    curses.init_pair(5, curses.COLOR_GREEN, curses.COLOR_BLACK)
    curses.init_pair(6, curses.COLOR_YELLOW, curses.COLOR_BLACK)
    curses.init_pair(7, curses.COLOR_BLUE, curses.COLOR_BLACK)

    get_data()

    while (k != ord('q')):
        stdscr.erase()
        height, width = stdscr.getmaxyx()

        empty_line = ' ' * width
        #stdscr.bkgd(' ', curses.color_pair(1) | curses.A_BOLD)

        line_num = 2
        for record in parser.lsLogs:
            nowtimestamp = datetime.now()
            strftime = nowtimestamp.strftime("%H:%M:%S %d.%m.%Y")
            stdscr.addstr(0, 0, "События безопасности информации по состоянию на " + strftime, curses.color_pair(1) | curses.A_BOLD)

            stdscr.addstr(1, 0, empty_line, curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 0, "Ур.", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 4, "Хост", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 12, "Дата", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 24, "Время", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 34, "IP-адрес", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 51, "Тема", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)
            stdscr.addstr(1, 100, "Сообщение", curses.color_pair(1) | curses.A_BOLD | curses.A_UNDERLINE)

            level = 0
            if record[0].isdigit(): level = int(record[0])
            if len(record) > 0:
                if level < 4: stdscr.addstr(line_num, 0,  record[0],  curses.color_pair(1) | curses.A_BOLD)
                if (level >= 4) and (level < 10): stdscr.addstr(line_num, 0,  record[0],  curses.color_pair(6) | curses.A_BOLD)
                if level >=10: stdscr.addstr(line_num, 0,  record[0],  curses.color_pair(3) | curses.A_BOLD)

            if len(record) > 1: stdscr.addstr(line_num, 4,  record[1],  curses.color_pair(1) | curses.A_BOLD)

            timestamp = getdatetimefromstr(record[2], record[3])
            delta = nowtimestamp - timestamp
            seconds = delta.total_seconds()
            minutes = seconds // 60

            if len(record) > 2: 
                if minutes < 15: stdscr.addstr(line_num, 12,  record[2],  curses.color_pair(1) | curses.A_BOLD)
                else: stdscr.addstr(line_num, 12,  record[2],  curses.color_pair(1))
            if len(record) > 3:
                if minutes < 15: stdscr.addstr(line_num, 24, record[3],  curses.color_pair(1) | curses.A_BOLD)
                else: stdscr.addstr(line_num, 24, record[3],  curses.color_pair(1))

            if len(record) > 4: stdscr.addstr(line_num, 34, record[4],  curses.color_pair(1))

            if len(record) > 5: 
                if level < 4: stdscr.addstr(line_num, 51, record[5],   curses.color_pair(1) | curses.A_BOLD)
                if (level >= 4) and (level < 10): stdscr.addstr(line_num, 51, record[5],   curses.color_pair(6) | curses.A_BOLD)
                if level >=10: stdscr.addstr(line_num, 51, record[5],   curses.color_pair(3) | curses.A_BOLD)

            if len(record) > 6: stdscr.addstr(line_num, 100, record[6],  curses.color_pair(1))
            if len(record) > 7: stdscr.addstr(line_num, 100, record[7],  curses.color_pair(1))
            if len(record) > 8: stdscr.addstr(line_num, 100, record[8],  curses.color_pair(1))
            if len(record) > 9: stdscr.addstr(line_num, 100, record[9],  curses.color_pair(1))
            if len(record) > 10:stdscr.addstr(line_num, 100, record[10], curses.color_pair(1))
            if len(record) > 11:stdscr.addstr(line_num, 100, record[11], curses.color_pair(1))
            if len(record) > 12:stdscr.addstr(line_num, 100, record[12], curses.color_pair(1))
            if len(record) > 13:stdscr.addstr(line_num, 100, record[13], curses.color_pair(1))
            if len(record) > 14:stdscr.addstr(line_num, 100, record[14], curses.color_pair(1))

            #stdscr.addstr(height - 1, 0, str(ccount), curses.color_pair(1))

            line_num = line_num + 1
            if line_num >= height - 1: 
                break
        stdscr.refresh()
        k = stdscr.getch()
        if k == curses.ERR:
            time.sleep(.3)
            ccount = ccount + 1
            if ccount > 60:
                ccount = 0
                get_data()


if __name__ == '__main__':
    try:
        curses.wrapper(draw_logs)
    except Exception:
        print(traceback.format_exc(10))
