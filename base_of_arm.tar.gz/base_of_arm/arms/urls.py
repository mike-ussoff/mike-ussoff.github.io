from django.urls import path
from django.views.generic.base import TemplateView
from arms import views
from django.views.generic import RedirectView

urlpatterns = [
    path('about/', TemplateView.as_view(template_name='about.html')),
    path('login/', views.login),
    path('logout/', views.logout),
    path('', RedirectView.as_view(url='list/')),
    path('list/', views.arms_list),
    path('list/<int:current_page>/', views.arms_list),
    path('detail/<int:id>/', views.arms_detail),
    path('edit/<int:id>/', views.arms_edit),
    path('delete/<int:id>/', views.arms_delete),
    path('new/', views.arms_edit),
    path('users/list/', views.arm_users_list),
    path('user/delete/<int:id>/', views.arm_user_delete),
    path('subdiv/delete/<int:id>/', views.arm_subdiv_delete),
    path('subdiv/edit/<int:id>/', views.arm_subdiv_edit),
    path('user/edit/<int:id>/', views.arm_user_edit),
    path('subdiv/new/', views.arm_subdiv_edit),
    path('user/new/', views.arm_user_edit),
    path('data/upload/arms/', views.upload_data_xlsx, {'filename': 'Перечень ОВТ 36070.xlsx'}),
    path('data/upload/users/', views.upload_data_xlsx, {'filename': 'Штатно-должностной расчет.xlsx'}),
    path('short_selection/', views.get_selection, {'type': 'short'}),
    path('detail_selection/', views.get_selection, {'type': 'detail'}),
    path('pzr/', views.get_selection, {'type': 'pzr'})
]