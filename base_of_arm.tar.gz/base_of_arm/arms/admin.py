from django.contrib import admin

# Register your models here.
from arms.models import Building, Arm, Subdivision, User

admin.site.register(Building)
admin.site.register(Subdivision)

class ArmAdmin(admin.ModelAdmin):
    filter_horizontal = ('users',)

admin.site.register(Arm, ArmAdmin)

class UserAdmin(admin.ModelAdmin):
    list_display = ('name1', 'name2', 'name3')
    list_filter = ('id',)

admin.site.register(User, UserAdmin)