from django.db import models

# Create your models here.


class Building(models.Model):
    title = models.CharField(max_length=50)
    def __str__(self):
        return self.title


class Subdivision(models.Model):
    n_div = models.CharField(max_length=10)
    title = models.CharField(max_length=255)
    oobi = models.ForeignKey('arms.User', null=True, default=None, blank=True, on_delete = models.SET_NULL) 
    def __str__(self):
        return u'%s\t %s' % (self.n_div, self.title)


class User(models.Model):
    n_div = models.CharField(max_length=10)
    n_position = models.CharField(max_length=10)
    rank = models.CharField(max_length=20)
    name1 = models.CharField(max_length=30)
    name2 = models.CharField(max_length=30)
    name3 = models.CharField(max_length=30)
    subdivision_id = models.ForeignKey(Subdivision, on_delete = models.PROTECT)
    def __str__(self):
        return u'%s\t %s %s %s' % (self.n_position, self.name1, self.name2, self.name3)


class Arm(models.Model):
    n_reg = models.CharField(max_length=20)
    category  = models.CharField(max_length=10)
    room = models.CharField(max_length=30)
    equipment = models.TextField(blank=True)
    buildings_id = models.ForeignKey(Building, on_delete = models.PROTECT)
    subdivision_id = models.ForeignKey(Subdivision, on_delete = models.PROTECT)
    oexe = models.ForeignKey(User, related_name = 'user_oexe', null = True, on_delete = models.SET_NULL)
    ozi = models.ForeignKey(User, related_name = 'user_ozi', null = True, on_delete = models.SET_NULL)
    users = models.ManyToManyField(User)
    def __str__(self):
        return u'Уч. №: %s, пом. : %s' % (self.n_reg, self.room)


