from django.shortcuts import render

# Create your views here.
import math
import re
import os
from django.http import HttpResponse, HttpResponseRedirect
from django.views.decorators.csrf import csrf_protect
from django.shortcuts import get_object_or_404
from arms.models import User, Subdivision, Building, Arm
from django.db import IntegrityError
from django.http import Http404
from django.contrib.auth import views as auth_views
import arms.generator


def get_obi_list():
    choice = [(0, 'Все')]
    selection = User.objects.filter(subdivision_id__title__contains = 'Отделение (обеспечения')
    for item in selection: choice.append( (item.id, item.name1) )
    return choice

def get_subdiv_list():
    choice = [(0, 'Все')]
    selection = Subdivision.objects.all()
    for item in selection: choice.append( (item.id, item.title) )
    return choice

def get_build_list():
    choice = [(0, 'Все')]
    selection = Building.objects.all()
    for item in selection: choice.append( (item.id, item.title) )
    return choice

def get_category_dict():
    choice = {'ДСП': 'Дсп',
              '3': 'Секретно',
              '2': 'Сов. секретно'}
    return choice

def get_category_list():
    choice = [('All', 'Все')]
    selection = get_category_dict().items()
    for item_id, item_title in selection: choice.append( (item_id, item_title) )
    return choice

choice_per_page = [ (0, 15), (1, 30), (2, 45) ]    


class Selection(object):
    def __init__(self, request):
        if request.method == 'POST':
            try:
                request.session['init_obi'] = int(request.POST.get('obi', '0'))
                request.session['init_div'] = int(request.POST.get('subdiv', '0'))
                request.session['init_build'] = int(request.POST.get('build', '0'))
                request.session['countlines'] = int(request.POST.get('countlines', '0'))
                request.session['init_category'] = request.POST.get('category', 'All')
                request.session['param'] = request.POST.get('param', 'family')
                request.session['find_field'] = request.POST.get('find_field', '')
            except ValueError:
                pass

        self.init_obi = request.session.get('init_obi', 0)
        self.init_div = request.session.get('init_div', 0)
        self.init_build = request.session.get('init_build', 0)
        self.countlines = request.session.get('countlines', 0)
        self.init_category = request.session.get('init_category', 'All')
        self.param = request.session.get('param', 'family') 
        self.find_field = request.session.get('find_field', '')

        if len(self.find_field) > 0:
            if self.param == 'mni':
                s = re.search(r'\d+[-]?[дспм]{,3}', self.find_field)
                if s == None:
                    self.find_field = ''
                else:
                    self.find_field = s[0]

            if self.param == 'family':
                s = re.search(r'[А-Яа-я ]+', self.find_field)
                if s == None:
                    self.find_field = ''
                else:
                    self.find_field = s[0]

            if self.param == 'jelezo':
                s = re.search(r'[А-Яа-яA-Za-z0-9 ]+', self.find_field)
                if s == None:
                    self.find_field = ''
                else:
                    self.find_field = s[0]
        
        self.lines_on_pages = 0
        for i in choice_per_page: 
            if self.countlines == i[0]: 
                self.lines_on_pages = i[1]



def get_selection_queryset(sel):
    arms = Arm.objects.all().order_by('subdivision_id')
    if sel.init_obi != 0:
        arms = arms.filter(subdivision_id__oobi = sel.init_obi)

    n_div = ''
    if sel.init_div != 0:
        sub = Subdivision.objects.get(pk = sel.init_div)
        n_div = sub.n_div
        arms = arms.filter(subdivision_id__n_div__startswith = n_div)

    #if sel.init_div != 0:
    #    arms = arms.filter(subdivision_id = sel.init_div)

    if sel.init_build != 0:
        arms = arms.filter(buildings_id = sel.init_build)
    if sel.init_category != 'All':
        if sel.init_category in get_category_dict().keys():
            arms = arms.filter(category = sel.init_category)

    if len(sel.find_field) > 0:
        if sel.param == 'mni':
            arms = arms.filter(n_reg__icontains = sel.find_field)

        if sel.param == 'family':
            arms = arms.filter(oexe__name1__istartswith = sel.find_field)

        if sel.param == 'jelezo':
            arms = arms.filter(equipment__icontains = sel.find_field)

    return arms



@csrf_protect
def arms_list(request, current_page = 1):
    request.session['menu'] = 1   

    sel = Selection(request)
    if request.method == 'POST':
        return HttpResponseRedirect('/arm/list/' + str(current_page) + '/')

    arms = get_selection_queryset(sel)

    count = arms.count()

    total_pages = math.ceil(count / sel.lines_on_pages)
    if total_pages < 1: total_pages = 1

    if current_page < 1: current_page = 1
    if current_page > total_pages: current_page = total_pages 

    start = sel.lines_on_pages * (current_page - 1)

    arms = arms[start:start + sel.lines_on_pages]

    class pages_bar():
        pages = []
        curr_page = current_page
        start_line = start 
    
    pg_bar = pages_bar()
    for i in range(1, total_pages + 1):
        pg_bar.pages.append(i)

    if current_page > 1:
        pg_bar.previous = current_page - 1
        pg_bar.b_prev = False
    else:
        pg_bar.previous = 1
        pg_bar.b_prev = True

    if current_page < total_pages:
        pg_bar.next = current_page + 1
        pg_bar.b_next = False
    else:
        pg_bar.next = total_pages
        pg_bar.b_next = True

    context = {'obis': get_obi_list(), 'init_obi': sel.init_obi, 'subdivisions': get_subdiv_list(), 
               'init_div' : sel.init_div, 'buildings': get_build_list(), 'init_build' : sel.init_build,
               'choice_per_page' : choice_per_page, 'countlines': sel.countlines, 'category': get_category_list(),
               'init_category': sel.init_category, 'param': sel.param, 'find_field': sel.find_field, 'pages_bar': pg_bar,
               'arms' : arms }    
    
    return render(request, 'arm_list.html', context)


def get_res(result):   # получаем список, возвращаем строку
    res_str = ''
    for disk in result:
        if len(res_str) > 0: res_str = res_str + '/'
        res_str = res_str + disk.strip()
    return res_str

class errors:
    def __init__(self):
        self.room = ''
        self.disk = ''        
    def is_present(self):
        if (self.room != '') or (self.disk != ''):
            return True
        else:
            return False


@csrf_protect
def arms_edit(request, id = 0): # id = 0 при создании АРМа
    request.session['menu'] = 1   

    error = errors()
    bad_request = 'Ошибка данных.'

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    if id == 0:
        obj = Arm()
        usr = []
    else:
        obj = get_object_or_404(Arm, pk=id)
        usr = obj.users.all()

    if request.method == 'POST':

        room_str = request.POST.get('room', '')
        if room_str == '':
            room = 'б/н'
        else:
            room = get_res(re.findall(r'^\s*\d+/\d\s*', room_str))  # format: 255/3
            if room == '':
                room = get_res(re.findall(r'^\s*\d+а*\s*', room_str)) # format: 255 or 255a
            if room == '':
                error.room = 'Формат помещений: 255, 255/3, 255a'

        disk_str = request.POST.get('disk', '')
        disk = get_res(re.findall(r'\d+[-]?[дспм]{,3}', get_res(re.split(r'\d\d\.\d\d\.\d+', disk_str))))
        if disk == '':
            error.disk = 'Формат учетных номеров: 125, 125дсп, 30м, 1525-д' 

        if not error.is_present():
            try:
                subdiv = int(request.POST.get('subdiv', '0'))
                build = int(request.POST.get('build', '0'))
                expl = int(request.POST.get('expl', '0'))
                zi = int(request.POST.get('zi', '0'))
            except ValueError:
                raise Http404(bad_request)

            if expl == 0: oexe = None
            else:         oexe = get_object_or_404(User, pk=expl)

            if zi == 0:   ozi = None
            else:         ozi = get_object_or_404(User, pk=zi)

            equipment = request.POST.get('equipment', '')
            parts = equipment.split('\n')
            equipment = ''
            for part in parts:
                part = part.strip()
                if len(part) > 0:
                    if len(equipment) > 0: equipment += '\n'    
                    equipment += part 

            subdiv = get_object_or_404(Subdivision, pk=subdiv)
            build = get_object_or_404(Building, pk=build)
            
            category_dict = get_category_dict()
            category = request.POST.get('category', '0')
            if not category in category_dict.keys():
                raise Http404(bad_request)

            try:
                obj.n_reg = disk
                obj.category = category
                obj.room = room
                obj.buildings_id = build
                obj.subdivision_id = subdiv
                obj.oexe = oexe
                obj.ozi = ozi
                obj.equipment = equipment
                obj.save()
            except IntegrityError:
                raise Http404(bad_request)

            ulist = []
            for item in request.POST.items():
                if item[0].find('user_') == 0:
                    s = item[0][5:]
                    try:
                        i = int(s)
                    except ValueError:
                        continue
                    ulist.append(i)
            try:
                obj.users.set(ulist)
            except IntegrityError:
                raise Http404(bad_request)

            return HttpResponseRedirect('/arm/detail/' + str(obj.id) +'/')

    buildings = Building.objects.all()
    subdivisions = Subdivision.objects.all()
    return render(request, 'arm_edit.html', {'obj': obj,
                                             'users': usr,
                                             'error': error,
                                             'buildings': buildings,
                                             'subdivisions': subdivisions,
                                             'category': get_category_dict() })


def arms_detail(request, id):
    request.session['menu'] = 1   

    obj = get_object_or_404(Arm, pk=id)
    usr = obj.users.all()
    equipment = obj.equipment.split('\n')

    return render(request, 'arm_detail.html', {'obj': obj,
                                               'users': usr,
                                               'equipment': equipment,
                                               'category': get_category_dict()[obj.category] })


def arms_delete(request, id):
    request.session['menu'] = 1   

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    obj = get_object_or_404(Arm, pk=id)

    try:
        obj.delete()
    except IntegrityError:
        raise Http404('Упс. Произошла ошибка удаления АРМ.')

    return HttpResponseRedirect('/arm/list/')    
                                               


class SelectionUsers(object):
    def __init__(self, request):
        if request.method == 'POST':
            try:
                request.session['init_div'] = int(request.POST.get('subdiv', '0'))
                request.session['find_family'] = request.POST.get('find_family', '')
            except ValueError:
                pass

        self.init_div = request.session.get('init_div', 0)
        self.find_field = request.session.get('find_family', '')

        if len(self.find_field) > 0:
            s = re.search(r'[А-Яа-я ]+', self.find_field)
            if s == None:
                self.find_field = ''
            else:
                self.find_field = s[0]


@csrf_protect
def arm_users_list(request):
    request.session['menu'] = 2   

    sel = SelectionUsers(request)
    if request.method == 'POST':
        return HttpResponseRedirect('/arm/users/list/')    

    n_div = ''
    if sel.init_div != 0:
        sub = Subdivision.objects.get(pk = sel.init_div)
        n_div = sub.n_div

    if n_div == '':
        subdivisions = Subdivision.objects.all()   
    else:
        subdivisions = Subdivision.objects.filter(n_div__startswith = n_div)

    #if len(sel.find_field) > 0:
    #    subdivisions = subdivisions.filter(user__name1__istartswith = sel.find_field)

    return render(request, 'arm_users.html', {'init_div': sel.init_div,
                                              'find_field': sel.find_field,
                                              'subdivlist': get_subdiv_list(), 
                                              'subdivisions': subdivisions })


def arm_user_delete(request, id):
    request.session['menu'] = 2   

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    obj = get_object_or_404(User, pk=id)

    try:
        obj.delete()
    except IntegrityError:
        raise Http404('Упс. Произошла ошибка удаления.')

    return HttpResponseRedirect('/arm/users/list/')    


def arm_subdiv_delete(request, id):
    request.session['menu'] = 2   

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    obj = get_object_or_404(Subdivision, pk=id)

    errors = []
    count_arm = obj.arm_set.all().count()

    if count_arm > 0:
        errors.append('ПЭВМ:')    
        for item in obj.arm_set.all():
            errors.append('=> ' + 'АРМ уч. № ' + item.n_reg)

    count_user = obj.user_set.all().count()
    if count_user > 0:
        errors.append('Пользователи:')    
        for item in obj.user_set.all():
            errors.append('=> ' + item.name1 + ' ' + item.name2 + ' ' + item.name3)

    if len(errors) == 0:
        try:
            obj.delete()
        except IntegrityError:
            raise Http404('Ошибка обновления базы данных.')

        return HttpResponseRedirect('/arm/users/list/')
    else:
        errors.insert(0, 'Объект "' + obj.title + '" не может быть удален, т.к. содержит зависимые объекты:')
    
    subdivisions = Subdivision.objects.all()   
    return render(request, 'arm_users.html', {'subdivisions': subdivisions,
                                              'errors': errors })


class errors2:
    def __init__(self):
        self.n_div = ''
        self.title = ''        
    def is_present(self):
        if (self.n_div != '') or (self.title != ''):
            return True
        else:
            return False

def get_param_findall(request, param_name, re_string, error_message):
    param_str = request.POST.get(param_name, '')
    param_o = re.findall(re_string, param_str)
    param = ''
    for i in param_o:
        param = param + i
    if param != param_str:
        return (param, error_message)
    return (param, '')

def get_param_search(request, param_name, re_string, error_message):
    param_str = request.POST.get(param_name, '')
    param_o = re.search(re_string, param_str)
    param = ''
    if param_o != None:
        param = param_o[0]
    if param != param_str:
        return (param, error_message)
    return (param, '')


def arm_subdiv_edit(request, id = 0):
    request.session['menu'] = 2   

    error = errors2()

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    if id == 0:
        obj = Subdivision()
    else:
        obj = get_object_or_404(Subdivision, pk=id)

    if request.method == 'POST':

        n_div, error.n_div = get_param_findall(request, 'n_div', r'\d+[.]{1,1}', 'Формат номера: 12., 12.3., 2.4.17.')
        title, error.title = get_param_search(request, 'title', r'[А-Яа-я()\- ]+', 'Недопустимые символы. Используйте А-Я, а-я, (, )')

        if not error.is_present():
            try:
                obj.n_div = n_div
                obj.title = title
                obj.save()   
            except IntegrityError:
                raise Http404('Ошибка обновления базы данных.')                    
            
            subdivisions = Subdivision.objects.all()   
            return HttpResponseRedirect('/arm/users/list/')

    return render(request, 'subdiv_edit.html', {'obj': obj, 'error': error })


class errors3:
    def __init__(self):
        self.n_position = ''
        self.rank  = ''
        self.name1 = ''
        self.name2 = ''
        self.name3 = ''
      
    def is_present(self):
        if (self.n_position != ''):
            return True
        if (self.rank != '') or (self.name1 != ''):
            return True
        if (self.name2 != '') or (self.name3 != ''):
            return True
        return False


def arm_user_edit(request, id = 0):
    request.session['menu'] = 2   

    error = errors3()

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    if id == 0:
        obj = User()
    else:
        obj = get_object_or_404(User, pk=id)

    if request.method == 'POST':

        try:
            subdiv = int(request.POST.get('subdiv', '0'))
        except ValueError:
            raise Http404('Ошибка данных')

        subdiv = get_object_or_404(Subdivision, pk=subdiv)
        n_div = subdiv.n_div

        n_position, error.n_position = get_param_findall(request, 'n_position', r'\d+[.]{1,1}', 'Формат номера: 12.3., 2.4.17. и т.д.')
        rank, error.rank = get_param_search(request, 'rank', r'[- А-Яа-я0-9/]+', 'Недопустимые символы. Используйте А-Я, а-я, 0-9')
        rank = rank.lower()

        name_error = 'Недопустимые символы. Используйте А-Я, а-я'

        name1, error.name1 = get_param_search(request, 'name1', r'[А-Яа-я ]+', name_error)
        name2, error.name2 = get_param_search(request, 'name2', r'[А-Яа-я ]+', name_error)
        name3, error.name3 = get_param_search(request, 'name3', r'[А-Яа-я ]+', name_error)

        if not error.is_present():
            try:
                obj.subdivision_id = subdiv
                obj.n_div = n_div
                obj.n_position = n_position
                obj.rank = rank
                obj.name1 = name1
                obj.name2 = name2
                obj.name3 = name3
                obj.save()   
            except IntegrityError:
                raise Http404('Ошибка обновления базы данных.')                    
            
            subdivisions = Subdivision.objects.all()
            return HttpResponseRedirect('/arm/users/list/')

    subdivisions = Subdivision.objects.all()
    return render(request, 'user_edit.html', {'obj': obj,
                                              'error': error,
                                              'subdivisions': subdivisions })



from .forms import DocumentForm
from .parser import parse_arms_xlsx, parse_users_xlsx


@csrf_protect
def upload_data_xlsx(request, filename):
    request.session['menu'] = 4   

    if not request.user.is_authenticated:
        return HttpResponseRedirect('/arm/login/')

    message = 'Укажите путь к файлу «' + filename + '»'

    # Handle file upload
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)

        if form.is_valid():
            f = request.FILES['docfile']
            file_name = f.name
            if filename == file_name:

                local_file_name = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

                if filename.find('Перечень') >= 0:
                    local_file_name += '/static/files/arms.xlsx'
                else:
                    local_file_name += '/static/files/users.xlsx'

                with open(local_file_name, 'wb+') as destination:
                    for chunk in f.chunks():
                        destination.write(chunk)
                    destination.close()
                
                if filename.find('Перечень') >= 0:
                    res, err = parse_arms_xlsx()
                else:
                    res, err = parse_users_xlsx()

                if not res:
                    message = 'Ошибка разбора «' + filename+ '»: ' + err
                else:
                    return HttpResponseRedirect('/arm/list/')
            else:
                message = 'Ошибка. Ожидается конкретный файл: «' + filename+ '»'
        else:
            message = 'Исправьте следующие ошибки:'
    else:
        form = DocumentForm() 
    context = {'form': form, 'message': message}
    return render(request, 'upload.html', context)


def get_next_page_after_login(request):
    current_page = request.session.get('menu', 1)
    next_page = '/arm/list/'
    if current_page == 2:
        next_page = '/arm/users/list/'
    return next_page


@csrf_protect
def login(request):
    next_page = get_next_page_after_login(request)
    request.session['menu'] = 5
    a = auth_views.LoginView.as_view(template_name='login.html', extra_context={'next':next_page})
    return a(request)


@csrf_protect
def logout(request):
    next_page = get_next_page_after_login(request)
    a = auth_views.LogoutView.as_view(next_page=next_page)   
    return a(request)


import mimetypes

def get_selection(request, type):

    filename = ''

    if type == 'short':
        sel = Selection(request)
        queryset = get_selection_queryset(sel)
        filename = arms.generator.create_short_selection(sel, queryset)

    if type == 'detail':
        sel = Selection(request)
        queryset = get_selection_queryset(sel)
        filename = arms.generator.create_detail_selection(sel, queryset)

    if type == 'pzr':
        filename = arms.generator.create_pzr()

    if filename == '':
        raise Http404('Неверный запрос')

    fp = open(filename, "rb")
    response = HttpResponse(fp.read())
    fp.close()

    file_type = mimetypes.guess_type(filename)
    if file_type is None:
        file_type = 'application/octet-stream'
    response['Content-Type'] = file_type
    response['Content-Length'] = str(os.stat(filename).st_size)
    response['Content-Disposition'] = "attachment; filename=" + os.path.basename(filename)
 
    return response

