import xlrd
import sqlite3
import re
import os
from django.db import connection


buildings = [
    ['Мобильный', 'МОБИЛЬ'],
    ['Здание № 1', 'ШТАБ'],
    ['Здание № 2', 'СТРОЙ'],
    ['Здание № 3', 'ДИСТ'],
    ['Здание № 4', 'КАЗАРМА'],
    ['Здание № 5', 'БУХ'],
    ['Спорткомплекс', 'СПОРТ']]

buildings_pair= {}

categoty_list = ['2', '3', 'ДСП']

clr_schema = [
    'delete from arms_arm_users;',
    'delete from arms_arm;',
    'delete from SQLite_sequence where name = "arms_arm";',
    'delete from arms_building;',
]

class user_class(object):
    def __init__(self, id , n_div , n_position , rank , name1 , name2 , name3):
        self.id = id  
        self.n_div = n_div 
        self.n_position = n_position 
        self.rank = rank
        self.name1 = name1
        self.name2 = name2
        self.name3 = name3

users = {}
def prepare_users(cursor):
    global users
    cursor.execute('select * from arms_user')
    for user in cursor.fetchall():
        id          = user[0]
        n_div       = user[1]
        n_position  = user[2]  
        rank        = user[3]  
        name1       = user[4]  
        name2       = user[5]  
        name3       = user[6]
        users[n_position] = user_class(id, n_div, n_position, rank, name1, name2, name3)

# загружаем список АРМ-ов

class ParseError(Exception):
    def __init__(self, data):
        self.data = data        
    def __str__(self):
        return repr(self.data)


def is_not_caption(row):
    res = True
    if len(row) > 3:
        if (row[1] == '') or (row[2] == '') or (row[3] == ''):
            res = False
    return res


def get_res(result):   # делаем по красоте
    res_str = ''
    for disk in result:
        if len(res_str) > 0: res_str = res_str + '/'
        res_str = res_str + disk.strip()
    return res_str


# получает ряд, возвращает идентификатор здания из БД
def get_building(row):
    row_value = (str(row[0])).strip()
    res_int = 0
    found = False
    for key in buildings_pair.keys():
        if row_value.upper().find(buildings_pair[key][1]) >= 0:
            res_int = key
            found = True
    if not found:
        raise ParseError('Здание? => ' + row_value)
    return res_int


# получает ряд, возвращает идентификатор подразделения из БД
def get_subdivision(row):
    value = (str(row[1])).strip()
    for key in users.keys():
        if users[key].n_position == value:
            value = users[key].n_div
    cursor = connection.cursor()
    cursor.execute('select id from arms_subdivision where n_div = :ndiv', {'ndiv': value})
    res_int = cursor.fetchone()
    if res_int == None:
        raise ParseError('Подразделение? => ' + row_value)
    return res_int[0]


# получает ряд, возвращает строку с номером помещения
def get_room(row):
    row_value = (str(row[3])).strip()
    res_str = get_res(re.findall(r'^\s*\d+/\d\s*', row_value))  # format: 255/3
    if res_str == '':
        res_str = get_res(re.findall(r'^\s*\d+а*\s*', row_value)) # format: 255 or 255a
    if res_str == '': 
        res_str = 'б/н'
    return res_str


# получает ряд, возвращает строку с категорией ПЭВМ (например: 2, 3, ДСП)
def get_category(row):
    row_value = (str(row[4])).strip()
    res_str = ''
    for key in categoty_list:
        if row_value.upper().find(key) >= 0:
            res_str = key
    if res_str == '': 
        raise ParseError('Категория? => ' + row_value)
    return res_str


# получает ряд, возвращает строку с учетным номером МНИ
def get_mni(row):
    row_value = (str(row[5])).strip()
    res_str = get_res(re.findall(r'\d+-\w+', row_value))  # format: 1525-д or 1525-сс or 1525-дсп
    if res_str == '':
        res_str = get_res(re.findall(r'\d+[дспм]*', get_res(re.split(r'\d\d\.\d\d\.\d+', row_value))))  # format: 125 or 125дсп or 30м
    if res_str == '': 
        raise ParseError('Учетный номер? => ' + row_value)
    return res_str


#  получает ряд, возвращает строку со списом оборудования (печатающими устройствами)
def get_printers(row):
    row_value = (str(row[7])).strip()
    res_list = ''
    row_value = row_value.split('\n')
    for device in row_value:
        if (device.upper().find('МФУ ') >= 0) or (device.upper().find('ПРИНТЕР ') >= 0):
            res_list = res_list + device + '\n'
    return res_list





rank_list = ['КАПИТАН','МАЙОР', 'ПОЛКОВНИК', 'ЛЕЙТЕНАНТ', 'МИЧМАН', 'СТАРШИЙ', 'СТАРШИНА', 'ГЛАВНЫЙ']
 
def is_valid_family(s):
    if s == '': return 
    if len(s) < 3:
        raise ParseError('Фамилия? => ' + s)
    fnd_str = s.upper()
    for sf in rank_list:
        if sf.find(fnd_str) >= 0:
            raise ParseError('Фамилия? => ' + s)


def get_family(value):
    res_str = re.findall(r'[А-Я][а-я]+', value)
    if type(res_str) == list:
        if len(res_str) > 0: res_str = res_str[0]
        else: res_str = ''
    is_valid_family(res_str)
    return res_str


def get_initials(value):
    res_str = re.findall(r'[А-Я]', value)    
    if type(res_str) == list:
        if len(res_str) > 0: res_str = ''.join(res_str)
        else: res_str = ''
    return res_str


# добавляет к списку из списка фамилий  (получает спискок фамилий, возвращает дополненный список идентификаторов в БД)
def append_users_from_field(value, usr_list):
    for emp in value:
        if emp == '': continue
        ss = get_family(emp)
        ss2 = get_initials(emp)
        ss = ss.upper()
        for key in users.keys():
            usr = users[key]
            sd = usr.name1
            sd = sd.upper()
            sd2 = usr.name1[0]
            if len(usr.name2) > 0: sd2 += usr.name2[0]
            if len(usr.name3) > 0: sd2 += usr.name3[0]
            if ss == sd:
                if (len(ss2) == 3) and (len(sd2) == 3) and (ss2 != sd2): continue
                if not usr.id in usr_list:
                    usr_list.append(usr.id)


# добавляет к списку допущенных к работе на ПЭВМ (получает ряд, возвращает дополненный список идентификаторов в БД)
def try_get_users_from_field(row, usr_list):
    append_users_from_field(str(row[14]).split('\n'), usr_list)
    return usr_list


# добавляет к списку сотрудников подразделения (получает ряд, возвращает дополненный список идентификаторов в БД)
def try_get_users_from_divs(row, usr_list):
    division  = str(row[1]).strip()
    stmp = re.findall(r'^\d+\.', division)[0]
    if len(stmp) == 0:
        raise ParseError('Подразделение? => ' + division)

    for key in users.keys():
        div = users[key].n_div 
        if div == division: usr_list.append(users[key].id)
        if key == division: usr_list.append(users[key].id)
    return usr_list


# добавляет к списку ответственных за защиту информации (получает ряд, возвращает дополненный список идентификаторов в БД)
def try_append_users_from_ozi(row, usr_list):
    append_users_from_field(str(row[13]).split('\n'), usr_list)
    return usr_list


# получает ряд и возвращает идентификатор ответственного за эксплуатацию из БД
def get_oexe(row):
    oexe = []
    append_users_from_field(str(row[12]).split('\n'), oexe)
    if len(oexe) > 0:
        return oexe[0]
    else:
        return None

# получает ряд и возвращает идентификатор ответственного за защиту информации из БД
def get_ozi(row):
    ozi = []
    append_users_from_field(str(row[13]).split('\n'), ozi)
    if len(ozi) > 0:
        return ozi[0]
    else:
        return None

# получает ряд и возвращает ответственного офицера ОБИ
def get_herr_officer(row):
    herr = []
    s = str(row[24])
    append_users_from_field(str(row[24]).split('\n'), herr)
    if len(herr) > 0:
        return herr[0]
    else:
        return None


def parse_arms_xlsx():
    try:
        cursor = connection.cursor()

        for command in clr_schema:
            cursor.execute(command)
        connection.commit()

        for key in buildings:
            cursor.execute('insert into arms_building (title) values (:building)', {'building': key[0]})
            buildings_pair[cursor.lastrowid] = key
        connection.commit()

        prepare_users(cursor)

        local_file_name = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        local_file_name += '/static/files/arms.xlsx'

        rb = xlrd.open_workbook(local_file_name)
        sheet = rb.sheet_by_name('ПЭВМ автономные')

        count_capt = 0
        for rownum in range(1, sheet.nrows):
            row = sheet.row_values(rownum)
            if is_not_caption(row):
                count_capt = 0

                context = { 'n_reg': get_mni(row), 'category': get_category(row), 'room': get_room(row), 'equipment': get_printers(row),
                            'oexe_id': get_oexe(row), 'ozi_id': get_ozi(row), 'buildings_id_id': get_building(row), 'subdivision_id_id':  get_subdivision(row) }

                cursor.execute('''insert into arms_arm (n_reg, category, room, equipment, buildings_id_id, oexe_id, ozi_id, subdivision_id_id) values 
                    (:n_reg, :category, :room, :equipment, :buildings_id_id, :oexe_id, :ozi_id, :subdivision_id_id)''', context)

                arm_id = cursor.lastrowid
                usr_list = []

                usr_list = try_get_users_from_field(row, usr_list)
                if len(usr_list) == 0:
                    usr_list = try_get_users_from_divs(row, usr_list)

                if len(usr_list) == 0:
                    raise ParseError('Подразделение? => ' + row[1])

                usr_list = try_append_users_from_ozi(row, usr_list)

                for usr in usr_list:
                    cursor.execute('insert into arms_arm_users (user_id, arm_id) values (:user_id, :arm_id)', { 'user_id': usr, 'arm_id': arm_id })
                connection.commit()

                herr_officer = get_herr_officer(row)
                if herr_officer != None:
                    cursor.execute('update arms_subdivision set oobi_id = :oobi_id where id = :id', { 'oobi_id': herr_officer, 'id': context['subdivision_id_id']})

            else:
                count_capt = count_capt + 1
                if count_capt > 3:
                    break

        connection.commit()

    except Exception as err:    
        return False, str(err) + '. Попробуйте сначала загрузить ШДР'

    return True, ''



# загружаем список пользователей

positions =['командующий', 'заместитель', 'помощник', 'секретарь', 'адъютант', 'начальник',
    'флагманский', 'старший', 'офицер', 'ведущий', 'главный', 'инженер', 'документовед', 'заведующ',
    'инструктор', 'психолог', 'инспектор', 'специалист', 'оперативный дежурный', 'оператор', 'телеграфист', 'техник']

def is_subdivision(row):
    result = True
    fnd_str = row[1].lower().strip()
    for word in positions:
        pattern = re.compile('^' + word)
        res_str = pattern.findall(fnd_str)
        if len(res_str): result = False 
    return result



update_user_command = '''update arms_user set n_div = :n_div, rank = :rank, name1 = :name1, 
                         name2 = :name2, name3 = :name3, subdivision_id_id = :id_subdivision 
                         where n_position = :n_position'''
insert_user_command = '''insert into arms_user (n_div, n_position, rank, name1, name2, 
                         name3, subdivision_id_id) values (:n_div, :n_position, :rank, :name1, 
                         :name2, :name3, :id_subdivision)'''
check_user_command = 'select count(n_position) from arms_user where n_position = :n_position'

update_subdiv_command = 'update arms_subdivision set title = :title where n_div = :n_div'
insert_subdiv_command = 'insert into arms_subdivision (n_div, title) values (:n_div, :title)'
check_subdiv_command = 'select id from arms_subdivision where n_div = :n_div'

def parse_sheet(sh_sheet):
    cursor = connection.cursor()
    id_subdivision = 0
    id_div = ''

    for rownum in range(1, sh_sheet.nrows):
        row = sh_sheet.row_values(rownum)
        if len(row[0]) > 0:
            if is_subdivision(row):
                id_div = (str(row[0])).strip()
                name_div = (str(row[1])).strip()

                params = {'n_div': id_div, 'title': name_div}

                cursor.execute(check_subdiv_command, params)
                res = cursor.fetchone()

                if res == None:
                    cursor.execute(insert_subdiv_command, params)
                    id_subdivision = cursor.lastrowid
                else:
                    id_subdivision = res[0]
                    cursor.execute(update_subdiv_command, params)

            else:
                n_position = (str(row[0])).strip()
                rank = (str(row[3])).strip()
                name1 = (str(row[4])).strip()
                name2 = (str(row[5])).strip()
                name3 = (str(row[6])).strip()
                if n_position.find(id_div) >= 0:
                    if len(name1) > 0:
                        params = { 'n_div': id_div,
                                   'n_position': n_position, 'rank': rank, 
                                   'name1' : name1, 'name2': name2, 
                                   'name3': name3, 'id_subdivision': id_subdivision }                            

                        cursor.execute(check_user_command, params)
                        res_int = cursor.fetchone()[0]

                        if res_int == 0:
                            cursor.execute(insert_user_command, params)
                        else:
                            cursor.execute(update_user_command, params)

    connection.commit()


def parse_users_xlsx():
    try:
        local_file_name = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        local_file_name += '/static/files/users.xlsx'
        sh_book = xlrd.open_workbook(local_file_name)
        sh_sheet = sh_book.sheet_by_name('27057')
        parse_sheet(sh_sheet)
        sh_sheet = sh_book.sheet_by_name('10931')
        parse_sheet(sh_sheet)

    except Exception as err:    
        return False, str(err)
    return True, ''
