import os
import docx
import re
from arms.models import User, Subdivision, Building, Arm


def set_standart_style(doc):
    # устанавливаем стандартный стиль документа
    style = doc.styles['Normal']
    style.paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.LEFT
    font = style.font
    font.name = 'Times New Roman'
    font.size = docx.shared.Pt(11)

    #разворачиваем страницу
    sections = doc.sections
    section = sections[0]

    #new_width, new_height = section.page_height, section.page_width
    section.orientation = docx.enum.section.WD_ORIENT.LANDSCAPE

    section.page_width = docx.shared.Cm(29.7)
    section.page_height = docx.shared.Cm(21)

    section.top_margin = docx.shared.Cm(1.5)
    section.bottom_margin = docx.shared.Cm(1.5)
    section.left_margin = docx.shared.Cm(1.7)
    section.right_margin = docx.shared.Cm(1.7)


def get_paragraph(doc):
    paragraph = doc.add_paragraph()
    paragraph_format = paragraph.paragraph_format
    paragraph_format.left_indent = docx.shared.Cm(0)
    paragraph_format.right_indent = docx.shared.Cm(0)
    paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.LEFT
    paragraph_format.first_line_indent = docx.shared.Pt(0)
    paragraph_format.space_before = docx.shared.Pt(0)
    paragraph_format.space_after = docx.shared.Pt(0)
    paragraph_format.line_spacing = docx.shared.Pt(0)
    return paragraph


def get_run(paragraph, text):
    run = paragraph.add_run(text)
    run.font.size = docx.shared.Pt(12)
    return run


def prep_name(user):
    res = ''
    if user == None:
        return res
    #if (user.rank != None) and (user.rank != 'г/п'):
    #    res += user.rank + ' '
    if user.name1 != None:
        res += user.name1 + ' '
    if (user.name2 != None) and (len(user.name2) > 0):
        res += user.name2[0] + '.'        
    if (user.name3 != None) and (len(user.name3) > 0):
        res += user.name3[0] + '.'        
    return res


def print_selection(doc, sel):
    paragraph = get_paragraph(doc)

    run = get_run(paragraph, 'Правила отбора:\n')
    run.bold = True

    if sel.init_obi != 0:
        obi = User.objects.get(pk = sel.init_obi)        
        get_run(paragraph, 'Офицер органа ОБИ: ' + prep_name(obi) + '\n')

    if sel.init_div != 0:
        div = Subdivision.objects.get(pk = sel.init_div)        
        get_run(paragraph, 'Подразделение: ' + div.title + '\n')

    if sel.init_build != 0:
        build = Building.objects.get(pk = sel.init_build)        
        get_run(paragraph, 'Здание: ' + build.title + '\n')

    if sel.init_category != 'All':
        get_run(paragraph, 'Категория: ' + sel.init_category + '\n')

    if len(sel.find_field) > 0:
        if sel.param == 'mni':
            get_run(paragraph, 'Учетный номер МНИ содержит: ' + sel.find_field + '\n')
        if sel.param == 'family':
            get_run(paragraph, 'Фамилия ответственного за эксплуатацию начинается с: ' + sel.find_field + '\n')
        if sel.param == 'jelezo':
            get_run(paragraph, 'Обороудование содержит: ' + sel.find_field + '\n')


def create_short_selection(sel, queryset):
    doc = docx.Document()

    set_standart_style(doc)

    print_selection(doc, sel)

    ROWNUMS = queryset.count() + 1
    COLNUMS = 8

    table = doc.add_table(cols=COLNUMS, rows=ROWNUMS)
    table.style = 'Table Grid'
    table.autofit = True
    table.allow_autofit = True

    table_cells = table._cells

    def get_cell(row, col):
        return table_cells[row * COLNUMS + col]

    def get_cell_run(row, col, text):
        return get_cell(row, col).paragraphs[0].add_run(text)

    # заголовок
    get_cell_run(0, 0, '№')
    get_cell_run(0, 1,'Подразделение')
    get_cell_run(0, 2, 'Ответственный')
    get_cell_run(0, 3, 'Отвественный за ЗИ')
    get_cell_run(0, 4, 'Учетный номер')
    get_cell_run(0, 5, 'Категория')
    get_cell_run(0, 6, 'Помещение')
    get_cell_run(0, 7, 'Здание')

    i = 1
    for item in queryset:
        get_cell_run(i, 0, str(i) + '.')
        get_cell_run(i, 1, item.subdivision_id.title)
        get_cell_run(i, 2, prep_name(item.oexe))
        get_cell_run(i, 3, prep_name(item.ozi))
        get_cell_run(i, 4, item.n_reg)
        get_cell_run(i, 5, item.category)
        get_cell_run(i, 6, item.room)
        get_cell_run(i, 7, item.buildings_id.title)
        i += 1

    save_file = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    save_file += '/static/files/short.docx'
    doc.save(save_file)
    return save_file




def create_detail_selection(sel, queryset):
    doc = docx.Document()

    #set_standart_style(doc)
    style = doc.styles['Normal']
    style.paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.LEFT
    font = style.font
    font.name = 'Times New Roman'
    font.size = docx.shared.Pt(11)

    print_selection(doc, sel)

    i = 1
    for item in queryset:
        paragraph = get_paragraph(doc)
        get_run(paragraph, str(i) + '.  --------------------------------------\n')
        get_run(paragraph, 'Подразделение: ' + item.subdivision_id.title + '\n')
        get_run(paragraph, 'Ответственный за эксплуатацию: ' + prep_name(item.oexe) + '\n')
        get_run(paragraph, 'Отвественный за ЗИ: ' + prep_name(item.ozi) + '\n')
        get_run(paragraph, 'Учетный номер: ' + item.n_reg + '\n')
        get_run(paragraph, 'Категория: ' + item.category + '\n')
        get_run(paragraph, 'Помещение: ' + item.room + '\n')
        get_run(paragraph, 'Здание: ' + item.buildings_id.title + '\n')

        get_run(paragraph, 'Оборудование:\n')
        equipment = item.equipment
        parts = equipment.split('\n')
        for part in parts:
            part = part.strip()
            if len(part) > 0: 
                get_run(paragraph, '\t' + part + '\n')

        get_run(paragraph, 'Допущенные:\n')
        for user in item.users.all():            
            get_run(paragraph, '\t' + prep_name(user) + '\n')

        i += 1

    save_file = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    save_file += '/static/files/detail.docx'
    doc.save(save_file)
    return save_file



def get_printers(equipment):
    printers = []
    eq_list = equipment.split('\n')
    for device in eq_list:
        if (device.upper().find('МФУ ') >= 0) or (device.upper().find('ПРИНТЕР ') >= 0):
            printers.append(device.strip())
    return printers


def get_category_str(str):
    if str == '2': return 'СС'
    if str == '3': return 'С'
    return 'ДСП'   


def get_profile_name(user):
    res = ''
    if user == None:
        return res
    if user.name1 != None:
        res += user.name1
    if (user.name2 != None) and (len(user.name2) > 0):
        res += user.name2[0]        
    if (user.name3 != None)  and (len(user.name3) > 0):
        res += user.name3[0]        
    return res


def get_full_name(user):
    res = ''
    if user == None:
        return res
    if (user.rank != None) and (user.rank != 'г/п'):
        res += user.rank + ' '
    return res + prep_name(user)



def create_pzr():
    doc = docx.Document()

    set_standart_style(doc)

    #рисуем шапку
    paragraph = get_paragraph(doc)
    paragraph_format = paragraph.paragraph_format
    paragraph_format.left_indent = docx.shared.Cm(22.5)
    paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER

    run = get_run(paragraph, 'СЕКРЕТНО')
    run.bold = True
    run.underline = True

    run = get_run(paragraph, '\nп.___ Перечня...')
    run = get_run(paragraph, '\nЭкз. № ___')

    paragraph = get_paragraph(doc)
    paragraph_format = paragraph.paragraph_format
    paragraph_format.left_indent = docx.shared.Cm(18.5)
    paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER

    run = get_run(paragraph, '\nУТВЕРЖДАЮ')

    paragraph = get_paragraph(doc)
    paragraph_format = paragraph.paragraph_format
    paragraph_format.left_indent = docx.shared.Cm(18.5)
    paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.LEFT

    run = get_run(paragraph, 'Начальник штаба ОВУ')
    run = get_run(paragraph, '\nкапитан 1 ранга')
    run = get_run(paragraph, '\n\t\t\t\t\tИ. Петров')
    run = get_run(paragraph, '\n«__» __________ 20__ года')

    paragraph = get_paragraph(doc)
    paragraph_format = paragraph.paragraph_format
    paragraph_format.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER
    run = get_run(paragraph, '\n\nПЕРЕЧЕНЬ')
    run.bold = True
    run = get_run(
        paragraph, '\nзащищаемых ресурсов на объектах информатизации штаба и управления ОВУ\n')

    # -------------------------------------------------------
    # вычисляем количество строк в таблице (требуется python-docx)

    lines = 2  # 2 строки - заголовок

    for arm in Arm.objects.all():
        lines = lines + 1
        lines += len(get_printers(arm.equipment))
        lines += arm.users.count()
        lines = lines + 1  # для CD/DVD

    # -------------------------------------------------------
    # рисуем таблицу
    ROWNUMS = lines
    COLNUMS = 13

    table = doc.add_table(cols=COLNUMS, rows=ROWNUMS)
    table.style = 'Table Grid'
    table.autofit = False
    table.allow_autofit = False

    table_cells = table._cells


    def get_cell(row, col):
        return table_cells[row * COLNUMS + col]


    def get_cell_run(row, col, text):
        return get_cell(row, col).paragraphs[0].add_run(text)


    get_cell(0, 0).merge(get_cell(1, 0))
    get_cell_run(0, 0, '№ п/п')
    get_cell(0, 1).merge(get_cell(0, 2))
    get_cell_run(0, 1, 'Наименование защищаемого ресурса')
    get_cell(0, 3).merge(get_cell(0, 4))
    get_cell_run(0, 3, 'Размещение в ЛВС')
    get_cell(0, 5).merge(get_cell(0, 6))
    get_cell_run(0, 5, 'Мандатная')
    get_cell(0, 7).merge(get_cell(0, 8)).merge(get_cell(0, 9)
                                           ).merge(get_cell(0, 10)).merge(get_cell(0, 11))
    get_cell_run(0, 7, 'Разрешенные виды доступа')
    get_cell(0, 12).merge(get_cell(1, 12))
    get_cell_run(0, 12, 'К ресурсу допущены')
    get_cell_run(1, 1, 'полное')
    get_cell_run(1, 2, 'условное')
    get_cell_run(1, 3, 'АРМ/МНИ')
    get_cell_run(1, 4, 'каталог')
    get_cell_run(1, 5, 'Метка')
    get_cell_run(1, 6, 'Категория')
    get_cell_run(1, 7, 'R')
    get_cell_run(1, 8, 'W')
    get_cell_run(1, 9, 'X')
    get_cell_run(1, 10, 'M')
    get_cell_run(1, 11, 'F')

    # -------------------------------------------------------

    i = 1   # фактический номер строки для вычисления положения в таблице    
    npp = 0 
    for arm in Arm.objects.all():
        npp += 1    # номер арма по порядку для вывода
        print('АРМ № ', npp)

        curr_no = 0 # номер пользователя/принтера/CD этого арма по порядку для вывода

        arm_num = 'АРМ №' + re.match(r'^\d+', arm.n_reg).group(0)
        arm_str = arm.buildings_id.title + ' пом. № ' + arm.room + ' ЖМД уч. № ' + arm.n_reg

        for user in arm.users.all():
            curr_no += 1    
            i += 1

            get_cell_run(i, 0, str(npp) + '.' + str(curr_no))
            get_cell_run(i, 1, 'Профиль пользователя')
            get_cell_run(i, 2, get_profile_name(user))
            get_cell_run(i, 3, arm_num)
            get_cell_run(i, 4, '%homepath%')
            get_cell_run(i, 5, get_category_str(arm.category))
            get_cell_run(i, 6, '-')
            get_cell_run(i, 7, '+')
            get_cell_run(i, 8, '+')
            get_cell_run(i, 9, '+')
            get_cell_run(i, 10, '+')
            get_cell_run(i, 11, '+')
            get_cell_run(i, 12, get_full_name(user))

        # DVD-RW
        curr_no += 1    
        i += 1
        get_cell_run(i, 0, str(npp) + '.' + str(curr_no))
        get_cell_run(i, 1, 'Устройство DVD-RW')
        get_cell_run(i, 2, '-')
        get_cell_run(i, 3, arm_num)
        get_cell_run(i, 4, '-')
        get_cell_run(i, 5, get_category_str(arm.category))
        get_cell_run(i, 6, '-')
        get_cell_run(i, 7, '-')
        get_cell_run(i, 8, '-')
        get_cell_run(i, 9, '-')
        get_cell_run(i, 10, '-')
        get_cell_run(i, 11, '-')
        get_cell_run(i, 12, 'Прошедшие проверку в СЗИ АРМ')

        # Принтер
        for printer in get_printers(arm.equipment):
            curr_no += 1    
            i += 1
            get_cell_run(i, 0, str(npp) + '.' + str(curr_no))
            if printer.find('МФУ') >= 0:
                get_cell_run(i, 1, 'МФУ')
                prn_type = re.sub('МФУ', '', printer).strip()
            else:
                prn_type = re.sub('Принтер', '', printer).strip()
                get_cell_run(i, 1, 'Принтер')
            get_cell_run(i, 2, prn_type)
            get_cell_run(i, 3, arm_num)
            get_cell_run(i, 4, '-')
            get_cell_run(i, 5, get_category_str(arm.category))
            get_cell_run(i, 6, '-')
            get_cell_run(i, 7, '+')
            get_cell_run(i, 8, '+')
            get_cell_run(i, 9, '-')
            get_cell_run(i, 10, '-')
            get_cell_run(i, 11, '-')
            get_cell_run(i, 12, 'Прошедшие проверку в СЗИ АРМ')

        # АРМ сам по себе
        curr_no += 1    
        i += 1

        get_cell(i, 10).merge(get_cell(i, 11))
        get_cell(i, 9).merge(get_cell(i, 10))
        get_cell(i, 8).merge(get_cell(i, 9))
        get_cell(i, 7).merge(get_cell(i, 8))
        get_cell(i, 6).merge(get_cell(i, 7))
        get_cell(i, 5).merge(get_cell(i, 6))
        get_cell(i, 4).merge(get_cell(i, 5))
        get_cell(i, 3).merge(get_cell(i, 4))
        get_cell(i, 2).merge(get_cell(i, 3))
        get_cell(i, 1).merge(get_cell(i, 2))
        get_cell_run(i, 0, str(npp) + '.' + str(curr_no))
        get_cell_run(i, 1, arm_str + '\n')
        get_cell_run(i, 12, 'Прошедшие проверку в СЗИ АРМ')

    print('Форматирование таблицы...')

    def set_column_width(column, width):
        for i in range(ROWNUMS):
            cell = get_cell(i, column)
            cell.width = width

    set_column_width(0, docx.shared.Cm(1.51))
    set_column_width(1, docx.shared.Cm(2.59))
    set_column_width(2, docx.shared.Cm(3.12))
    set_column_width(3, docx.shared.Cm(4.22))
    set_column_width(4, docx.shared.Cm(2.57))
    set_column_width(5, docx.shared.Cm(1.47))
    set_column_width(6, docx.shared.Cm(1.62))
    set_column_width(7, docx.shared.Cm(0.7))
    set_column_width(8, docx.shared.Cm(0.7))
    set_column_width(9, docx.shared.Cm(0.7))
    set_column_width(10, docx.shared.Cm(0.7))
    set_column_width(11, docx.shared.Cm(0.7))
    set_column_width(12, docx.shared.Cm(6.2))

    # -------------------------------------------------------

    # рисуем таблицу с членами комиссии

    paragraph = doc.add_paragraph()

    ROWNUMS = 5
    COLNUMS = 3

    table = doc.add_table(5, 3)
    table.alignment = docx.enum.text.WD_ALIGN_PARAGRAPH.CENTER

    table_cells = table._cells
    get_cell_run(0, 0, 'Председатель комиссии:')
    get_cell_run(0, 1, 'капитан 1 ранга')
    get_cell_run(0, 2, 'С. Иванов')
    get_cell_run(1, 0, 'Члены комиссии:')
    get_cell_run(1, 1, 'капитан 3 ранга')
    get_cell_run(1, 2, 'А. Петров')
    get_cell_run(2, 1, 'капитан-лейтенант')
    get_cell_run(2, 2, 'Р. Сидоров')
    get_cell_run(3, 1, 'старший лейтенант')
    get_cell_run(3, 2, 'Д. Сергеев')
    get_cell_run(4, 2, 'П. Володин')


    set_column_width(0, docx.shared.Cm(5.22))
    set_column_width(1, docx.shared.Cm(5.87))
    set_column_width(2, docx.shared.Cm(3.73))

    save_file = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    save_file += '/static/files/perechenb.docx'
    doc.save(save_file)
    print('Выполнено.')

    return save_file
