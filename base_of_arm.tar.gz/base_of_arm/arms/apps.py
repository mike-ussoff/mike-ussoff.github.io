from django.apps import AppConfig


class ArmsConfig(AppConfig):
    name = 'arms'
