#!/bin/bash

uwsgi --ini mysite_uwsgi.ini
